
import React from 'react';
import { HashRouter, Routes, Route } from 'react-router-dom';
import { Layout } from './components/Layout';
import { Home } from './pages/Home';
import { Switches } from './pages/Switches';
import { Admin } from './pages/Admin';
import { Contact } from './pages/Contact';

// Simple placeholders for missing pages
const Placeholder = ({ title }: { title: string }) => (
  <div className="max-w-7xl mx-auto px-4 py-24 text-center">
    <h1 className="text-4xl font-bold text-white mb-4">{title}</h1>
    <p className="text-slate-400">This section is being populated with the latest keyboard community content.</p>
  </div>
);

const App: React.FC = () => {
  return (
    <HashRouter>
      <Layout>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/guides" element={<Placeholder title="Beginner Guides" />} />
          <Route path="/switches" element={<Switches />} />
          <Route path="/layouts" element={<Placeholder title="Keyboard Layouts & Sizes" />} />
          <Route path="/build-guide" element={<Placeholder title="Step-by-Step Build Guide" />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/admin" element={<Admin />} />
          <Route path="/privacy" element={<Placeholder title="Privacy Policy" />} />
          <Route path="/terms" element={<Placeholder title="Terms of Use" />} />
        </Routes>
      </Layout>
    </HashRouter>
  );
};

export default App;
