
import { useState, useEffect } from 'react';
import { Article, Switch, KeyboardLayout, AppSettings, ContactSubmission } from './types';
import { INITIAL_ARTICLES, INITIAL_SWITCHES, INITIAL_LAYOUTS, INITIAL_SETTINGS } from './constants';

export const useStore = () => {
  const [articles, setArticles] = useState<Article[]>(() => {
    const saved = localStorage.getItem('kc_articles');
    return saved ? JSON.parse(saved) : INITIAL_ARTICLES;
  });

  const [switches, setSwitches] = useState<Switch[]>(() => {
    const saved = localStorage.getItem('kc_switches');
    return saved ? JSON.parse(saved) : INITIAL_SWITCHES;
  });

  const [layouts, setLayouts] = useState<KeyboardLayout[]>(() => {
    const saved = localStorage.getItem('kc_layouts');
    return saved ? JSON.parse(saved) : INITIAL_LAYOUTS;
  });

  const [settings, setSettings] = useState<AppSettings>(() => {
    const saved = localStorage.getItem('kc_settings');
    return saved ? JSON.parse(saved) : INITIAL_SETTINGS;
  });

  const [submissions, setSubmissions] = useState<ContactSubmission[]>(() => {
    const saved = localStorage.getItem('kc_submissions');
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => {
    localStorage.setItem('kc_articles', JSON.stringify(articles));
  }, [articles]);

  useEffect(() => {
    localStorage.setItem('kc_switches', JSON.stringify(switches));
  }, [switches]);

  useEffect(() => {
    localStorage.setItem('kc_layouts', JSON.stringify(layouts));
  }, [layouts]);

  useEffect(() => {
    localStorage.setItem('kc_settings', JSON.stringify(settings));
  }, [settings]);

  useEffect(() => {
    localStorage.setItem('kc_submissions', JSON.stringify(submissions));
  }, [submissions]);

  return {
    articles, setArticles,
    switches, setSwitches,
    layouts, setLayouts,
    settings, setSettings,
    submissions, setSubmissions
  };
};
