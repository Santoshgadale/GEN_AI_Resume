
import { Article, Switch, KeyboardLayout, AppSettings } from './types';

export const INITIAL_ARTICLES: Article[] = [
  {
    id: '1',
    title: 'The Beginner\'s Guide to Custom Keyboards',
    slug: 'beginners-guide',
    excerpt: 'Everything you need to know to get started with your first custom mechanical keyboard build.',
    content: 'Mechanical keyboards offer a superior typing experience compared to standard membrane keyboards. They use individual switches for each key, providing tactile feedback and durability...',
    category: 'Guides',
    difficulty: 'Beginner',
    author: 'Alex Chen',
    date: '2024-05-15',
    imageUrl: 'https://images.unsplash.com/photo-1618384881928-24cd52720fb6?q=80&w=1480&auto=format&fit=crop',
    isFeatured: true
  },
  {
    id: '2',
    title: 'Understanding Switch Physics',
    slug: 'switch-physics',
    excerpt: 'Deep dive into actuation points, bottom-out forces, and stem designs.',
    content: 'To understand why switches feel different, we need to look at the internal components: the stem, the spring, and the housing leaf...',
    category: 'Educational',
    difficulty: 'Advanced',
    author: 'Sarah Jenkins',
    date: '2024-05-10',
    imageUrl: 'https://images.unsplash.com/photo-1595225476474-87563907a212?q=80&w=1471&auto=format&fit=crop',
    isFeatured: false
  }
];

export const INITIAL_SWITCHES: Switch[] = [
  {
    id: 's1',
    name: 'Cherry MX Blue',
    brand: 'Cherry',
    type: 'Clicky',
    actuationForce: 60,
    travelDistance: 4.0,
    characteristics: ['Audible click', 'Tactile bump', 'Popular for typing'],
    description: 'The quintessential clicky switch with a sharp tactile bump.'
  },
  {
    id: 's2',
    name: 'Gateron Yellow',
    brand: 'Gateron',
    type: 'Linear',
    actuationForce: 50,
    travelDistance: 4.0,
    characteristics: ['Smooth', 'Quiet', 'Budget friendly'],
    description: 'A smooth linear switch that is widely considered the best budget option.'
  }
];

export const INITIAL_LAYOUTS: KeyboardLayout[] = [
  {
    id: 'l1',
    name: 'Full-Size (100%)',
    percentage: '100%',
    keys: 104,
    description: 'The standard layout with numpad and function row.',
    pros: ['Includes everything', 'No layers needed'],
    cons: ['Takes up lots of desk space', 'Ergonomically less ideal for mouse'],
    imageUrl: 'https://images.unsplash.com/photo-1511467687858-23d96c32e4ae?q=80&w=1470&auto=format&fit=crop'
  },
  {
    id: 'l2',
    name: 'Tenkeyless (TKL / 80%)',
    percentage: '80%',
    keys: 87,
    description: 'Standard layout minus the numeric keypad.',
    pros: ['Standard spacing', 'More mouse space'],
    cons: ['No numpad'],
    imageUrl: 'https://images.unsplash.com/photo-1595225476474-87563907a212?q=80&w=1471&auto=format&fit=crop'
  }
];

export const INITIAL_SETTINGS: AppSettings = {
  siteName: 'KeyCraft Hub',
  heroHeadline: 'Master Your Typing Craft',
  heroSubheadline: 'Your ultimate discovery engine for switches, layouts, and custom builds.',
  accentColor: 'indigo',
  darkMode: true
};
