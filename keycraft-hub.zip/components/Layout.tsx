
import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useStore } from '../store';

const Navbar: React.FC = () => {
  const { settings } = useStore();
  const location = useLocation();
  const isAdminPath = location.pathname.startsWith('/admin');

  if (isAdminPath) return null;

  const links = [
    { name: 'Home', path: '/' },
    { name: 'Guides', path: '/guides' },
    { name: 'Switches', path: '/switches' },
    { name: 'Layouts', path: '/layouts' },
    { name: 'Build Guide', path: '/build-guide' },
    { name: 'Contact', path: '/contact' },
  ];

  return (
    <nav className="sticky top-0 z-50 bg-slate-950/80 backdrop-blur-md border-b border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <Link to="/" className="flex items-center space-x-2">
            <div className={`w-8 h-8 bg-${settings.accentColor}-600 rounded flex items-center justify-center`}>
              <i className="fas fa-keyboard text-white text-sm"></i>
            </div>
            <span className="text-xl font-bold tracking-tight text-white">{settings.siteName}</span>
          </Link>
          <div className="hidden md:flex space-x-8">
            {links.map((link) => (
              <Link 
                key={link.path} 
                to={link.path} 
                className={`${location.pathname === link.path ? 'text-indigo-400' : 'text-slate-300 hover:text-white'} transition-colors font-medium text-sm uppercase tracking-wider`}
              >
                {link.name}
              </Link>
            ))}
          </div>
          <div className="flex items-center space-x-4">
            <Link to="/admin" className="p-2 text-slate-400 hover:text-white">
              <i className="fas fa-cog"></i>
            </Link>
            <button className="md:hidden text-slate-400">
              <i className="fas fa-bars text-xl"></i>
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
};

const Footer: React.FC = () => {
  const { settings } = useStore();
  const location = useLocation();
  const isAdminPath = location.pathname.startsWith('/admin');

  if (isAdminPath) return null;

  return (
    <footer className="bg-slate-900 border-t border-slate-800 pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center space-x-2 mb-6">
              <div className={`w-8 h-8 bg-${settings.accentColor}-600 rounded flex items-center justify-center`}>
                <i className="fas fa-keyboard text-white"></i>
              </div>
              <span className="text-2xl font-bold text-white">{settings.siteName}</span>
            </div>
            <p className="text-slate-400 max-w-sm mb-6">
              Empowering enthusiasts to build, customize, and discover the perfect typing experience. Join our community and master your craft.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center text-slate-400 hover:bg-indigo-600 hover:text-white transition-all">
                <i className="fab fa-twitter"></i>
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center text-slate-400 hover:bg-indigo-600 hover:text-white transition-all">
                <i className="fab fa-discord"></i>
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center text-slate-400 hover:bg-indigo-600 hover:text-white transition-all">
                <i className="fab fa-youtube"></i>
              </a>
            </div>
          </div>
          <div>
            <h4 className="text-white font-bold mb-6">Quick Links</h4>
            <ul className="space-y-4 text-slate-400">
              <li><Link to="/guides" className="hover:text-indigo-400">Beginner Guides</Link></li>
              <li><Link to="/switches" className="hover:text-indigo-400">Switch Comparisons</Link></li>
              <li><Link to="/layouts" className="hover:text-indigo-400">Layout Guide</Link></li>
              <li><Link to="/contact" className="hover:text-indigo-400">Contact Us</Link></li>
            </ul>
          </div>
          <div>
            <h4 className="text-white font-bold mb-6">Legal</h4>
            <ul className="space-y-4 text-slate-400">
              <li><Link to="/privacy" className="hover:text-indigo-400">Privacy Policy</Link></li>
              <li><Link to="/terms" className="hover:text-indigo-400">Terms of Use</Link></li>
              <li><Link to="/admin" className="hover:text-indigo-400">Admin Login</Link></li>
            </ul>
          </div>
        </div>
        <div className="border-t border-slate-800 pt-8 flex flex-col md:flex-row justify-between items-center text-slate-500 text-sm">
          <p>&copy; {new Date().getFullYear()} {settings.siteName}. All rights reserved.</p>
          <p className="mt-4 md:mt-0">Crafted with passion for enthusiasts.</p>
        </div>
      </div>
    </footer>
  );
};

export const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-grow">
        {children}
      </main>
      <Footer />
    </div>
  );
};
