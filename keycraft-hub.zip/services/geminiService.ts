
import { GoogleGenAI } from "@google/genai";

export const generateArticleSummary = async (content: string): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Summarize the following mechanical keyboard article content in exactly two punchy sentences for a meta description: ${content}`,
    });
    return response.text?.trim() || "No summary available.";
  } catch (error) {
    console.error("AI Generation Error:", error);
    return "Error generating summary.";
  }
};

export const getSwitchAdvice = async (preferences: string): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Based on these preferences: "${preferences}", suggest 3 mechanical keyboard switches and briefly explain why. Use a friendly expert tone.`,
    });
    return response.text?.trim() || "Could not generate advice.";
  } catch (error) {
    console.error("AI Generation Error:", error);
    return "Error generating advice.";
  }
};
