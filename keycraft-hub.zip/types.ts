
export type Difficulty = 'Beginner' | 'Intermediate' | 'Advanced';

export interface Article {
  id: string;
  title: string;
  slug: string;
  excerpt: string;
  content: string;
  category: string;
  difficulty: Difficulty;
  author: string;
  date: string;
  imageUrl: string;
  isFeatured: boolean;
}

export interface Switch {
  id: string;
  name: string;
  brand: string;
  type: 'Linear' | 'Tactile' | 'Clicky';
  actuationForce: number;
  travelDistance: number;
  characteristics: string[];
  description: string;
}

export interface KeyboardLayout {
  id: string;
  name: string;
  percentage: string;
  keys: number;
  description: string;
  pros: string[];
  cons: string[];
  imageUrl: string;
}

export interface ContactSubmission {
  id: string;
  name: string;
  email: string;
  message: string;
  timestamp: string;
}

export interface AppSettings {
  siteName: string;
  heroHeadline: string;
  heroSubheadline: string;
  accentColor: string;
  darkMode: boolean;
}
