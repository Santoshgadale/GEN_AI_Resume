
import React, { useState } from 'react';
import { useStore } from '../store';

export const Contact: React.FC = () => {
  const { setSubmissions, submissions } = useStore();
  const [form, setForm] = useState({ name: '', email: '', message: '' });
  const [status, setStatus] = useState<'idle' | 'success'>('idle');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newSubmission = {
      id: Date.now().toString(),
      ...form,
      timestamp: new Date().toISOString()
    };
    setSubmissions([newSubmission, ...submissions]);
    setForm({ name: '', email: '', message: '' });
    setStatus('success');
    setTimeout(() => setStatus('idle'), 3000);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-20">
        <div>
          <h1 className="text-5xl font-black text-white mb-6">Get in Touch</h1>
          <p className="text-slate-400 text-xl leading-relaxed mb-10">
            Have questions about a specific build or want to contribute to the community? We're here to help enthusiasts like you.
          </p>
          
          <div className="space-y-8">
            <div className="flex items-start space-x-6">
              <div className="w-12 h-12 rounded-2xl bg-slate-800 flex items-center justify-center text-indigo-400 shrink-0">
                <i className="fas fa-envelope text-xl"></i>
              </div>
              <div>
                <h4 className="text-white font-bold">Email Us</h4>
                <p className="text-slate-500">support@keycrafthub.com</p>
              </div>
            </div>
            <div className="flex items-start space-x-6">
              <div className="w-12 h-12 rounded-2xl bg-slate-800 flex items-center justify-center text-indigo-400 shrink-0">
                <i className="fab fa-discord text-xl"></i>
              </div>
              <div>
                <h4 className="text-white font-bold">Join Discord</h4>
                <p className="text-slate-500">discord.gg/keycrafthub</p>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-8 md:p-12 rounded-3xl shadow-2xl relative overflow-hidden">
          {status === 'success' && (
            <div className="absolute inset-0 bg-indigo-600 z-20 flex flex-col items-center justify-center text-white p-8">
              <i className="fas fa-check-circle text-6xl mb-4"></i>
              <h3 className="text-2xl font-bold mb-2">Message Received!</h3>
              <p className="text-indigo-100 text-center">We'll get back to you faster than a speed switch actuation.</p>
            </div>
          )}
          
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-slate-400 text-sm font-bold mb-2 uppercase tracking-widest">Full Name</label>
              <input 
                required
                type="text" 
                value={form.name}
                onChange={(e) => setForm({...form, name: e.target.value})}
                placeholder="John Doe" 
                className="w-full bg-slate-950 border border-slate-700 rounded-xl p-4 text-white placeholder:text-slate-600 focus:outline-none focus:ring-2 focus:ring-indigo-600 focus:border-transparent transition-all"
              />
            </div>
            <div>
              <label className="block text-slate-400 text-sm font-bold mb-2 uppercase tracking-widest">Email Address</label>
              <input 
                required
                type="email" 
                value={form.email}
                onChange={(e) => setForm({...form, email: e.target.value})}
                placeholder="john@example.com" 
                className="w-full bg-slate-950 border border-slate-700 rounded-xl p-4 text-white placeholder:text-slate-600 focus:outline-none focus:ring-2 focus:ring-indigo-600 focus:border-transparent transition-all"
              />
            </div>
            <div>
              <label className="block text-slate-400 text-sm font-bold mb-2 uppercase tracking-widest">Your Message</label>
              <textarea 
                required
                rows={5}
                value={form.message}
                onChange={(e) => setForm({...form, message: e.target.value})}
                placeholder="Tell us what's on your mind..." 
                className="w-full bg-slate-950 border border-slate-700 rounded-xl p-4 text-white placeholder:text-slate-600 focus:outline-none focus:ring-2 focus:ring-indigo-600 focus:border-transparent transition-all resize-none"
              />
            </div>
            <button className="w-full bg-indigo-600 text-white font-bold py-5 rounded-xl text-lg hover:bg-indigo-700 transition-all shadow-xl shadow-indigo-600/20">
              Send Message
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
