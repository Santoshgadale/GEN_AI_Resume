
import React, { useState } from 'react';
import { useStore } from '../store';
import { getSwitchAdvice } from '../services/geminiService';

export const Switches: React.FC = () => {
  const { switches } = useStore();
  const [filter, setFilter] = useState<'All' | 'Linear' | 'Tactile' | 'Clicky'>('All');
  const [prefInput, setPrefInput] = useState('');
  const [aiAdvice, setAiAdvice] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const filteredSwitches = filter === 'All' 
    ? switches 
    : switches.filter(s => s.type === filter);

  const handleAiAdvice = async () => {
    if (!prefInput) return;
    setIsLoading(true);
    const advice = await getSwitchAdvice(prefInput);
    setAiAdvice(advice);
    setIsLoading(false);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
      <div className="mb-12">
        <h1 className="text-4xl font-bold text-white mb-4">Switch Comparison</h1>
        <p className="text-slate-400 max-w-2xl">The heart of every keyboard. Explore different switch types and find the one that fits your typing style.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
        {/* Comparison List */}
        <div className="lg:col-span-2 space-y-8">
          <div className="flex items-center space-x-2 overflow-x-auto pb-2 custom-scrollbar">
            {['All', 'Linear', 'Tactile', 'Clicky'].map((type) => (
              <button
                key={type}
                onClick={() => setFilter(type as any)}
                className={`px-4 py-2 rounded-full text-sm font-bold transition-all whitespace-nowrap ${
                  filter === type 
                    ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/20' 
                    : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
                }`}
              >
                {type}
              </button>
            ))}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {filteredSwitches.map((s) => (
              <div key={s.id} className="bg-slate-900 border border-slate-800 rounded-2xl p-6 hover:border-indigo-500/50 transition-all group">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="text-xl font-bold text-white">{s.name}</h3>
                    <span className="text-slate-500 text-sm">{s.brand}</span>
                  </div>
                  <span className={`px-3 py-1 rounded-md text-[10px] font-black uppercase tracking-widest ${
                    s.type === 'Linear' ? 'bg-red-500/10 text-red-400' :
                    s.type === 'Tactile' ? 'bg-orange-500/10 text-orange-400' :
                    'bg-blue-500/10 text-blue-400'
                  }`}>
                    {s.type}
                  </span>
                </div>
                <p className="text-slate-400 text-sm mb-6 line-clamp-2">{s.description}</p>
                <div className="grid grid-cols-2 gap-4 mb-6">
                  <div className="bg-slate-800/50 rounded-lg p-3">
                    <span className="text-[10px] text-slate-500 uppercase block font-bold mb-1">Actuation</span>
                    <span className="text-white font-bold">{s.actuationForce}g</span>
                  </div>
                  <div className="bg-slate-800/50 rounded-lg p-3">
                    <span className="text-[10px] text-slate-500 uppercase block font-bold mb-1">Travel</span>
                    <span className="text-white font-bold">{s.travelDistance}mm</span>
                  </div>
                </div>
                <div className="flex flex-wrap gap-2">
                  {s.characteristics.map((c, i) => (
                    <span key={i} className="px-2 py-1 bg-slate-800 rounded text-[10px] text-slate-400 font-medium">#{c}</span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* AI Sidebar */}
        <div className="space-y-8">
          <div className="bg-indigo-600/10 border border-indigo-500/20 rounded-2xl p-8 sticky top-24">
            <h3 className="text-xl font-bold text-white mb-4 flex items-center">
              <i className="fas fa-robot mr-3 text-indigo-400"></i>
              AI Switch Advisor
            </h3>
            <p className="text-slate-400 text-sm mb-6 leading-relaxed">
              Not sure what you want? Tell me about your preferences (e.g., "I love quiet keyboards but hate the mushy laptop feel") and I'll suggest a path.
            </p>
            <textarea
              value={prefInput}
              onChange={(e) => setPrefInput(e.target.value)}
              placeholder="Describe your typing feel..."
              className="w-full bg-slate-900/80 border border-slate-700 rounded-xl p-4 text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 mb-4 h-32"
            />
            <button
              onClick={handleAiAdvice}
              disabled={isLoading || !prefInput}
              className="w-full bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white font-bold py-3 rounded-xl transition-all shadow-lg shadow-indigo-600/20"
            >
              {isLoading ? <i className="fas fa-circle-notch fa-spin mr-2"></i> : null}
              Get Recommendation
            </button>

            {aiAdvice && (
              <div className="mt-8 pt-8 border-t border-indigo-500/20">
                <div className="text-indigo-300 text-sm leading-relaxed italic">
                  "{aiAdvice}"
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
