
import React from 'react';
import { Link } from 'react-router-dom';
import { useStore } from '../store';

export const Home: React.FC = () => {
  const { settings, articles } = useStore();
  const featuredArticles = articles.filter(a => a.isFeatured);

  return (
    <div className="space-y-24 pb-24">
      {/* Hero Section */}
      <section className="relative h-[80vh] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-slate-900 to-slate-950 z-0"></div>
        <div className="absolute -top-24 -left-24 w-96 h-96 bg-indigo-600/20 rounded-full blur-[120px] z-0"></div>
        <div className="absolute -bottom-24 -right-24 w-96 h-96 bg-cyan-600/10 rounded-full blur-[120px] z-0"></div>
        
        <div className="relative z-10 text-center max-w-4xl px-4">
          <h1 className="text-5xl md:text-7xl font-extrabold text-white mb-6 tracking-tight leading-tight">
            {settings.heroHeadline}
          </h1>
          <p className="text-xl md:text-2xl text-slate-400 mb-10 leading-relaxed">
            {settings.heroSubheadline}
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-4">
            <Link to="/guides" className="px-8 py-4 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg font-bold text-lg transition-all shadow-lg shadow-indigo-600/25 w-full sm:w-auto">
              Explore Keyboards
            </Link>
            <Link to="/switches" className="px-8 py-4 bg-slate-800 hover:bg-slate-700 text-white border border-slate-700 rounded-lg font-bold text-lg transition-all w-full sm:w-auto">
              Compare Switches
            </Link>
          </div>
        </div>
      </section>

      {/* Intro Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <div>
            <span className="text-indigo-400 font-bold tracking-widest uppercase text-sm mb-4 block">The Fundamentals</span>
            <h2 className="text-4xl font-bold text-white mb-6">Why Mechanical?</h2>
            <p className="text-slate-400 text-lg leading-relaxed mb-6">
              A standard keyboard uses a rubber dome under every key. A mechanical keyboard uses a discrete physical switch. This single difference changes everything: the feel, the sound, the responsiveness, and the longevity of your main interface with the digital world.
            </p>
            <ul className="space-y-4">
              {[
                { icon: 'fa-feather', title: 'Tactile Feedback', desc: 'Feel exactly when a key registers.' },
                { icon: 'fa-shield-halved', title: 'Durability', desc: 'Built to last 50-100 million keystrokes.' },
                { icon: 'fa-palette', title: 'Full Customization', desc: 'Swap every switch and keycap to your liking.' }
              ].map((item, idx) => (
                <li key={idx} className="flex items-start space-x-4">
                  <div className="w-10 h-10 rounded-lg bg-slate-800 flex items-center justify-center flex-shrink-0 text-indigo-400">
                    <i className={`fas ${item.icon}`}></i>
                  </div>
                  <div>
                    <h4 className="text-white font-bold">{item.title}</h4>
                    <p className="text-slate-500">{item.desc}</p>
                  </div>
                </li>
              ))}
            </ul>
          </div>
          <div className="relative">
            <div className="aspect-video rounded-2xl overflow-hidden shadow-2xl shadow-indigo-500/10">
              <img src="https://images.unsplash.com/photo-1541140134513-85a161dc4a00?q=80&w=1470&auto=format&fit=crop" alt="Keyboard setup" className="w-full h-full object-cover" />
            </div>
            <div className="absolute -bottom-8 -left-8 bg-indigo-600 p-8 rounded-2xl hidden md:block">
              <span className="text-5xl font-black text-white block">10k+</span>
              <span className="text-indigo-100 font-medium">Daily Typists</span>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Articles */}
      <section className="bg-slate-900 py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-end mb-12">
            <div>
              <h2 className="text-4xl font-bold text-white mb-4">Latest Insights</h2>
              <p className="text-slate-400">Master your keyboard knowledge with our expert guides.</p>
            </div>
            <Link to="/guides" className="text-indigo-400 font-bold hover:text-indigo-300 transition-colors hidden sm:block">
              View All Articles <i className="fas fa-arrow-right ml-2"></i>
            </Link>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {articles.slice(0, 3).map((article) => (
              <Link to={`/guides/${article.slug}`} key={article.id} className="group">
                <div className="bg-slate-800 rounded-2xl overflow-hidden border border-slate-700 transition-all group-hover:border-indigo-500/50 group-hover:shadow-xl group-hover:shadow-indigo-500/5">
                  <div className="aspect-[16/10] overflow-hidden">
                    <img 
                      src={article.imageUrl} 
                      alt={article.title} 
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" 
                    />
                  </div>
                  <div className="p-6">
                    <div className="flex items-center space-x-2 mb-3">
                      <span className="text-xs font-bold uppercase tracking-widest text-indigo-400">{article.category}</span>
                      <span className="text-slate-600 text-xs">•</span>
                      <span className="text-xs text-slate-400">{article.difficulty}</span>
                    </div>
                    <h3 className="text-xl font-bold text-white mb-3 group-hover:text-indigo-300 transition-colors">{article.title}</h3>
                    <p className="text-slate-400 text-sm line-clamp-2">{article.excerpt}</p>
                    <div className="mt-6 flex items-center justify-between text-slate-500 text-xs uppercase font-bold">
                      <span>{article.author}</span>
                      <span>{article.date}</span>
                    </div>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-indigo-600 rounded-3xl p-12 md:p-20 text-center relative overflow-hidden">
          <div className="absolute top-0 right-0 p-4 text-indigo-500/20 text-[20rem] font-black pointer-events-none select-none">
            HUB
          </div>
          <div className="relative z-10 max-w-2xl mx-auto">
            <h2 className="text-4xl md:text-5xl font-black text-white mb-6">Ready to start your first build?</h2>
            <p className="text-indigo-100 text-lg mb-10 leading-relaxed">
              Join thousands of enthusiasts getting weekly tips, curated switch reviews, and early access to layout guides.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <input 
                type="email" 
                placeholder="Enter your email" 
                className="bg-white/10 border border-white/20 text-white placeholder:text-indigo-200 px-6 py-4 rounded-xl focus:outline-none focus:ring-2 focus:ring-white/40 w-full sm:max-w-xs"
              />
              <button className="bg-white text-indigo-600 px-8 py-4 rounded-xl font-bold hover:bg-indigo-50 transition-all shadow-xl">
                Subscribe Now
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
