
import React, { useState } from 'react';
import { useStore } from '../store';
import { Article, Switch, KeyboardLayout } from '../types';
import { generateArticleSummary } from '../services/geminiService';

export const Admin: React.FC = () => {
  const { articles, setArticles, switches, setSwitches, layouts, setLayouts, submissions, settings, setSettings } = useStore();
  const [activeTab, setActiveTab] = useState<'Articles' | 'Switches' | 'Layouts' | 'Messages' | 'Settings'>('Articles');
  const [editingArticle, setEditingArticle] = useState<Partial<Article> | null>(null);
  const [isAiLoading, setIsAiLoading] = useState(false);

  const handleDeleteArticle = (id: string) => {
    setArticles(articles.filter(a => a.id !== id));
  };

  const handleSaveArticle = () => {
    if (!editingArticle?.title) return;
    if (editingArticle.id) {
      setArticles(articles.map(a => a.id === editingArticle.id ? (editingArticle as Article) : a));
    } else {
      const newArticle = {
        ...editingArticle,
        id: Date.now().toString(),
        slug: editingArticle.title.toLowerCase().replace(/ /g, '-'),
        date: new Date().toISOString().split('T')[0],
        author: 'Admin'
      } as Article;
      setArticles([...articles, newArticle]);
    }
    setEditingArticle(null);
  };

  const handleAiSummary = async () => {
    if (!editingArticle?.content) return;
    setIsAiLoading(true);
    const summary = await generateArticleSummary(editingArticle.content);
    setEditingArticle({ ...editingArticle, excerpt: summary });
    setIsAiLoading(false);
  };

  return (
    <div className="min-h-screen bg-slate-950 flex">
      {/* Sidebar */}
      <aside className="w-64 bg-slate-900 border-r border-slate-800 p-6 flex flex-col fixed inset-y-0">
        <div className="flex items-center space-x-2 mb-10">
          <div className="w-8 h-8 bg-indigo-600 rounded flex items-center justify-center">
            <i className="fas fa-lock text-white text-xs"></i>
          </div>
          <span className="font-black text-white tracking-widest text-lg">KC ADMIN</span>
        </div>
        <nav className="flex-grow space-y-2">
          {['Articles', 'Switches', 'Layouts', 'Messages', 'Settings'].map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab as any)}
              className={`w-full text-left px-4 py-3 rounded-lg font-bold text-sm transition-all ${
                activeTab === tab ? 'bg-indigo-600 text-white shadow-lg' : 'text-slate-400 hover:bg-slate-800'
              }`}
            >
              <i className={`fas fa-${tab === 'Articles' ? 'file-alt' : tab === 'Switches' ? 'toggle-on' : tab === 'Layouts' ? 'th-large' : tab === 'Messages' ? 'envelope' : 'cog'} mr-3 w-5`}></i>
              {tab}
            </button>
          ))}
        </nav>
        <div className="pt-6 border-t border-slate-800">
          <a href="/" className="text-slate-400 hover:text-white text-sm font-bold flex items-center">
            <i className="fas fa-external-link-alt mr-3"></i>
            View Website
          </a>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-grow ml-64 p-10 overflow-auto">
        <header className="flex justify-between items-center mb-10">
          <h1 className="text-3xl font-black text-white">{activeTab}</h1>
          {activeTab === 'Articles' && (
            <button 
              onClick={() => setEditingArticle({ isFeatured: false, difficulty: 'Beginner', category: 'Guides' })}
              className="bg-indigo-600 text-white px-6 py-2 rounded-lg font-bold hover:bg-indigo-700 transition-all shadow-lg"
            >
              New Article
            </button>
          )}
        </header>

        {activeTab === 'Articles' && (
          <div className="grid grid-cols-1 gap-4">
            {articles.map((a) => (
              <div key={a.id} className="bg-slate-900 border border-slate-800 p-4 rounded-xl flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <img src={a.imageUrl} className="w-16 h-10 object-cover rounded" alt="" />
                  <div>
                    <h3 className="text-white font-bold">{a.title}</h3>
                    <div className="flex space-x-2 text-[10px] uppercase font-bold text-slate-500">
                      <span>{a.category}</span>
                      <span>•</span>
                      <span>{a.date}</span>
                    </div>
                  </div>
                </div>
                <div className="flex space-x-2">
                  <button 
                    onClick={() => setEditingArticle(a)}
                    className="p-2 text-slate-400 hover:text-indigo-400"
                  >
                    <i className="fas fa-edit"></i>
                  </button>
                  <button 
                    onClick={() => handleDeleteArticle(a.id)}
                    className="p-2 text-slate-400 hover:text-red-400"
                  >
                    <i className="fas fa-trash"></i>
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {activeTab === 'Messages' && (
          <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden">
            <table className="w-full text-left">
              <thead className="bg-slate-800 text-slate-400 text-xs uppercase font-bold">
                <tr>
                  <th className="px-6 py-4">Sender</th>
                  <th className="px-6 py-4">Message</th>
                  <th className="px-6 py-4">Date</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800 text-slate-300">
                {submissions.length === 0 ? (
                  <tr><td colSpan={3} className="px-6 py-12 text-center text-slate-500 italic">No messages found.</td></tr>
                ) : (
                  submissions.map((s) => (
                    <tr key={s.id}>
                      <td className="px-6 py-4">
                        <div className="font-bold text-white">{s.name}</div>
                        <div className="text-xs text-slate-500">{s.email}</div>
                      </td>
                      <td className="px-6 py-4 text-sm max-w-md">{s.message}</td>
                      <td className="px-6 py-4 text-xs">{new Date(s.timestamp).toLocaleDateString()}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        )}

        {activeTab === 'Settings' && (
          <div className="max-w-2xl bg-slate-900 border border-slate-800 p-8 rounded-2xl space-y-6">
            <div>
              <label className="block text-slate-400 text-sm font-bold mb-2">Site Name</label>
              <input 
                value={settings.siteName}
                onChange={(e) => setSettings({...settings, siteName: e.target.value})}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-3 text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
              />
            </div>
            <div>
              <label className="block text-slate-400 text-sm font-bold mb-2">Hero Headline</label>
              <input 
                value={settings.heroHeadline}
                onChange={(e) => setSettings({...settings, heroHeadline: e.target.value})}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-3 text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
              />
            </div>
            <div>
              <label className="block text-slate-400 text-sm font-bold mb-2">Accent Color Theme</label>
              <div className="flex space-x-3">
                {['indigo', 'cyan', 'rose', 'emerald'].map(color => (
                  <button 
                    key={color}
                    onClick={() => setSettings({...settings, accentColor: color})}
                    className={`w-10 h-10 rounded-full bg-${color}-600 ${settings.accentColor === color ? 'ring-4 ring-white' : ''}`}
                  />
                ))}
              </div>
            </div>
            <div className="pt-6 border-t border-slate-800 flex justify-end">
              <button className="bg-indigo-600 text-white px-8 py-3 rounded-xl font-black shadow-lg">SAVE SETTINGS</button>
            </div>
          </div>
        )}
      </main>

      {/* Article Editor Modal */}
      {editingArticle && (
        <div className="fixed inset-0 bg-slate-950/90 z-50 flex items-center justify-center p-6">
          <div className="bg-slate-900 border border-slate-800 w-full max-w-4xl max-h-[90vh] overflow-auto rounded-3xl p-8 custom-scrollbar">
            <h2 className="text-2xl font-black text-white mb-8">Edit Article</h2>
            <div className="grid grid-cols-2 gap-8 mb-8">
              <div className="space-y-4">
                <div>
                  <label className="block text-slate-400 text-xs font-bold uppercase mb-2">Title</label>
                  <input 
                    value={editingArticle.title || ''} 
                    onChange={(e) => setEditingArticle({...editingArticle, title: e.target.value})}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg p-3 text-white text-sm"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 text-xs font-bold uppercase mb-2">Image URL</label>
                  <input 
                    value={editingArticle.imageUrl || ''} 
                    onChange={(e) => setEditingArticle({...editingArticle, imageUrl: e.target.value})}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg p-3 text-white text-sm"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-slate-400 text-xs font-bold uppercase mb-2">Category</label>
                    <select 
                      value={editingArticle.category || 'Guides'} 
                      onChange={(e) => setEditingArticle({...editingArticle, category: e.target.value})}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg p-3 text-white text-sm"
                    >
                      <option>Guides</option>
                      <option>Educational</option>
                      <option>Reviews</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-slate-400 text-xs font-bold uppercase mb-2">Difficulty</label>
                    <select 
                      value={editingArticle.difficulty || 'Beginner'} 
                      onChange={(e) => setEditingArticle({...editingArticle, difficulty: e.target.value as any})}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg p-3 text-white text-sm"
                    >
                      <option>Beginner</option>
                      <option>Intermediate</option>
                      <option>Advanced</option>
                    </select>
                  </div>
                </div>
              </div>
              <div>
                <label className="block text-slate-400 text-xs font-bold uppercase mb-2 flex justify-between">
                  Excerpt (Summary)
                  <button 
                    onClick={handleAiSummary}
                    disabled={isAiLoading}
                    className="text-indigo-400 hover:text-indigo-300 disabled:opacity-50"
                  >
                    {isAiLoading ? <i className="fas fa-circle-notch fa-spin mr-1"></i> : <i className="fas fa-magic mr-1"></i>}
                    Auto-summarize
                  </button>
                </label>
                <textarea 
                  value={editingArticle.excerpt || ''} 
                  onChange={(e) => setEditingArticle({...editingArticle, excerpt: e.target.value})}
                  className="w-full h-[180px] bg-slate-950 border border-slate-800 rounded-lg p-3 text-white text-sm resize-none"
                />
              </div>
            </div>
            <div className="mb-8">
              <label className="block text-slate-400 text-xs font-bold uppercase mb-2">Full Content (Markdown/HTML Support)</label>
              <textarea 
                value={editingArticle.content || ''} 
                onChange={(e) => setEditingArticle({...editingArticle, content: e.target.value})}
                className="w-full h-48 bg-slate-950 border border-slate-800 rounded-lg p-3 text-white text-sm"
              />
            </div>
            <div className="flex justify-end space-x-4">
              <button onClick={() => setEditingArticle(null)} className="px-6 py-2 text-slate-400 font-bold">Cancel</button>
              <button onClick={handleSaveArticle} className="px-8 py-2 bg-indigo-600 text-white font-bold rounded-lg shadow-xl hover:bg-indigo-700">Save Article</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
